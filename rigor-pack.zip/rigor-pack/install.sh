#!/usr/bin/env bash
# Iwo's Rigor Pack v1.0.0 installer
# Writes 6 skills into ~/.claude/skills/. Inspect before running.
set -euo pipefail
DEST="${HOME}/.claude/skills"
mkdir -p "${DEST}"
mkdir -p "${DEST}/plan-gate"
cat > "${DEST}/plan-gate/SKILL.md" <<'RIGOR_EOF_PLAN_GATE'
---
name: plan-gate
description: Use before starting ANY task that involves more than one edit, file, or step - coding, refactoring, writing, configuration, migrations. Forces a short written plan (goal, unknowns, success criteria, step order) BEFORE the first change. Do not use for single-line fixes or pure questions.
---

# plan-gate: no edits until the plan exists

The most expensive failure mode in agentic work is not a wrong answer. It is discovering the real shape of the task halfway through changing things. This skill makes that discovery happen BEFORE anything changes, when it costs nothing.

## The gate

Before your first edit, write a plan in your response. Not in your head. Written, visible, in this exact shape:

```
GOAL: <one sentence: what is true when this is done>
UNKNOWNS: <what you have not verified yet - each with how you will verify it>
SUCCESS CRITERIA: <how you and the user will KNOW it worked - a command, a test, an observable>
STEPS: <numbered, smallest useful granularity, verification steps included>
OUT OF SCOPE: <adjacent things you noticed but will NOT touch>
```

Rules:
1. **The plan comes from evidence, not memory.** Read the relevant files and run the relevant read-only commands FIRST. A plan written before looking is a guess with formatting.
2. **Every unknown gets a verification step.** "Probably X" is not a plan line. "Check whether X by doing Y" is.
3. **Success criteria must be executable.** "Code works" fails this test. "npm test passes and GET /health returns 200" passes it.
4. **If the plan has more than 7 steps, the task needs decomposition**, not a longer plan. Split it and gate each part.
5. **When reality contradicts the plan mid-task, STOP and re-plan.** Do not improvise past a surprise. A surprised plan is an invalid plan. State what changed, update the plan, then continue.

## What this catches

- The hidden dependency you would have found at step 4 with three files already half-edited.
- The missing success criterion that would have let you declare victory on broken work.
- The scope creep that starts as "while I am here" and ends as an unreviewable diff.

## Anti-patterns this skill exists to kill

- Diving in: first tool call is an edit.
- The mental plan: "I know what to do" followed by discovering you did not.
- The pivot cascade: three abandoned half-approaches in one session because none was planned.

## Exception

Trivial tasks (one obvious edit, zero unknowns) may skip the written plan. Say "trivial, skipping plan-gate" so the skip is a decision, not a lapse. If you are wrong about it being trivial, the moment you notice is the moment you stop and write the plan.
RIGOR_EOF_PLAN_GATE
mkdir -p "${DEST}/adversarial-verify"
cat > "${DEST}/adversarial-verify/SKILL.md" <<'RIGOR_EOF_ADVERSARIAL_VERIFY'
---
name: adversarial-verify
description: Use after completing any substantive piece of work (code change, analysis, document, configuration, answer to a hard question) and BEFORE presenting it as done. Switches you from author to attacker - you try to refute your own work and only present it if it survives. Do not skip because the work "looks clean"; plausible-but-wrong is the exact failure this kills.
---

# adversarial-verify: refute it before you present it

Work that merely looks correct and work that is correct are indistinguishable to the person who just wrote it. The author's eye confirms. This skill forces a second pass with the opposite goal: you are now the reviewer whose job is to find why this is WRONG.

## The switch

When you finish a piece of work, run this pass BEFORE presenting. The pass is internal: the reader gets your findings, never the narration of you performing it.

1. **State the claim precisely.** What exactly am I asserting? ("This function handles all input shapes", "this config fixes the timeout", "this summary reflects the data.") Vague claims cannot be attacked, which is what makes them dangerous.
2. **Attack the requirements before your answer to them.** Read the spec, ticket, or question as a hostile lawyer: do any two rules contradict each other? Is a stated absolute ("always", "never", "ever") revoked by another clause? Does the requested interface conflict with the requested behavior? A contradiction you resolve silently is a decision you made for someone else without telling them - surface it, state your resolution, and invite the correction. This attack comes first because a flawless implementation of a broken spec is still broken.
3. **Attack the inputs.** Empty, zero, negative, huge, malformed, concurrent, unicode, missing. For each: what actually happens? Trace or run it. Do not assume.
4. **Attack the assumptions.** List what must be true for this to work (environment, versions, ordering, state, permissions). Verify the load-bearing ones against reality, not memory.
5. **Attack the evidence.** Did I actually observe it working, or do I merely find it convincing? "It compiles" is not "it works". "The test passes" means little if the test cannot fail - check that the test would catch the bug it guards.
6. **Run the strongest available check.** Tests, typechecker, linter, a manual execution, a re-read of the diff line by line. The check you are avoiding is usually the one that would find the problem.

## Verdicts

The pass ends in one of three internal verdicts, which shape what you present:
- **SURVIVED**: present the work. Include findings that the reader needs (the edge cases that matter, what was checked), stated as facts, not as a verification diary.
- **REFUTED**: fix what broke, run the pass again on the fix, and present the corrected work with the defect named plainly.
- **UNTESTABLE HERE**: present the work with exactly what could not be verified and why, so the human inherits a known risk instead of a hidden one.

## Rules

- The refutation pass gets real effort. A token "looks good to me" re-read is theater and worse than nothing because it launders false confidence.
- **The deliverable stays lean.** Findings earn their place in it, process does not. "I attacked this from five angles" is narration, cut it. "Fails on empty input, fixed" is a finding, keep it. A verification pass that doubles the length of your answer has failed at its own job.
- Report failures faithfully. If the test suite is red, the answer is the red output, not a narrative about being close.
- Never weaken the claim to dodge the attack ("works in most cases") without flagging the retreat explicitly.

## The tell

If you notice you WANT to skip this pass, that is the strongest signal it will find something. Reluctance to verify is data.
RIGOR_EOF_ADVERSARIAL_VERIFY
mkdir -p "${DEST}/live-state-truth"
cat > "${DEST}/live-state-truth/SKILL.md" <<'RIGOR_EOF_LIVE_STATE_TRUTH'
---
name: live-state-truth
description: Use whenever you are about to assert or act on a fact about a system - what a function does, what a config is set to, what is deployed, what a table contains, what a dependency's version is. Forces verification against the LIVE system before the assertion. Docs, comments, READMEs, and your own memory are treated as stale by default.
---

# live-state-truth: the system is the source of truth, not its description

Every system carries two versions of itself: what it IS, and what its documentation, comments, and everyone's memory SAY it is. They drift apart the moment they are written. Acting on the description when the system disagrees is how confident agents ship confident breakage.

## The rule

Before asserting a fact about a system, or taking an action whose safety depends on that fact, verify it against the live state:

| The claim comes from | Treat it as | Verify by |
|---|---|---|
| A README, doc, or wiki | Stale by default | Run the code path, read the actual source |
| A code comment | The code's opinion of itself | Read the code the comment describes |
| A config file in the repo | What was INTENDED | Query the running system for the EFFECTIVE value |
| Your memory or an earlier session | A point-in-time observation | Re-check now, the system moved since |
| The user's description | Honest but possibly outdated | Confirm gently with a read-only probe |
| A schema or type definition | Better, but migrations lie | Inspect actual data or live schema when it matters |

## The procedure

1. **Name the load-bearing facts.** Which facts, if wrong, make my next action wrong or destructive? Those are the ones to verify. Not everything - the ones the action stands on.
2. **Pick the cheapest sufficient check.** If the authoritative artifact is already in front of you (the source file, the actual config), the check IS reading it - do that and answer. Reach for probes (run it, query it, curl it) when the truth is NOT in view or when behavior could differ from what the text implies. Never add ceremony to a question the material on hand already answers.
3. **When description and reality disagree, reality wins - and say so.** The gap itself is a finding. Report it in one line ("the README says X, the code does Y") instead of silently following either.
4. **Timestamp what you learn.** "As of this check, X" ages honestly. "X is true" rots silently.
5. **Answer first, evidence second, tersely.** The deliverable is the verified answer plus the one-line evidence chain. Do not narrate your checking process or claim checks you cannot actually run here - unverifiable "I ran it" framing destroys the very trust this skill exists to build.

## Especially before destructive or state-changing actions

Deletes, overwrites, restarts, migrations, force-pushes: the evidence bar rises with the blast radius. A signal that pattern-matches a known situation can have a different cause. Look at the actual target first. If what you find contradicts how it was described, stop and surface the contradiction instead of proceeding.

## Anti-patterns this skill kills

- Recommending a flag that was removed two versions ago because a blog post said it exists.
- "The comment says this handles retries" - it did, before the refactor.
- Trusting your session memory of a file you edited an hour ago (someone or something may have edited it since).
- Building on a "known" API response shape without one real sample.

## The cheap habit

One probe before one claim. It costs seconds and is the single highest-ratio rigor habit an agent can have.
RIGOR_EOF_LIVE_STATE_TRUTH
mkdir -p "${DEST}/scope-fence"
cat > "${DEST}/scope-fence/SKILL.md" <<'RIGOR_EOF_SCOPE_FENCE'
---
name: scope-fence
description: Use on every task where you will modify existing work - code, documents, configs. Fences your changes to exactly what was asked. Adjacent problems get FLAGGED, never silently fixed. Keeps diffs minimal and reviewable. Do not use it to refuse legitimate follow-through the task actually requires.
---

# scope-fence: do what was asked, flag what you found

The most reviewable diff is the one that contains exactly the requested change and nothing else. Every unrequested improvement mixed into it costs double: the reviewer must now untangle what was asked from what was volunteered, and every extra line is a new place to introduce a regression nobody asked you to risk.

## The fence

1. **Restate the task as a boundary.** One sentence: "The task is X. The fence is: files/behavior needed for X." Write it before editing.
2. **Inside the fence: full effort.** Do X completely, including its genuine requirements (the import X needs, the test X breaks). Follow-through that X requires is IN scope.
3. **Outside the fence: eyes open, hands off.** You will see broken things - dead code, a bug in a neighboring function, an outdated comment, ugly formatting. You do not touch them. You record them.
4. **Flag, do not fix.** End your work with a FENCE REPORT:

```
FENCE REPORT
Changed: <files touched, each traceable to the task>
Noticed, NOT touched: <adjacent issue> - <why it matters> - <suggested follow-up>
```

A good fence report is a gift: the user gets the clean diff they asked for AND a map of what else deserves attention, each item now a deliberate decision instead of a surprise in the diff.

## Decision rules for the gray zone

- Would the requested change BREAK without this extra edit? Then it is in scope.
- Is it merely "while I am here"? Out. Flag it.
- Formatting churn on untouched lines (editor auto-format, import reordering)? Revert it before presenting - it is diff noise.
- Does the fix the user asked for reveal the real bug is elsewhere? Stop and say so - do not silently relocate the fence. Re-fence with the user.

## Anti-patterns this skill kills

- The 40-file diff for a one-line fix.
- The drive-by refactor that "improved" a function the task never mentioned and broke its one weird caller.
- Style opinions applied to code you were not asked to judge.
- The helpful rename that invalidated three open branches.

## The honest tension

Sometimes the adjacent problem genuinely is worse than the task. The answer is still the fence: finish X, then flag it with your recommendation, and let the human redirect you. "I noticed something worse, want me to switch?" costs one exchange. The uninvited mixed diff costs trust.
RIGOR_EOF_SCOPE_FENCE
mkdir -p "${DEST}/ruthless-editor"
cat > "${DEST}/ruthless-editor/SKILL.md" <<'RIGOR_EOF_RUTHLESS_EDITOR'
---
name: ruthless-editor
description: Use whenever you produce prose a human will read - documentation, READMEs, reports, summaries, commit messages, emails, blog drafts, PR descriptions. Runs a cutting pass where every sentence must earn its place. Target: 30 percent shorter with zero information loss. Do not use on code or on text the user asked you to preserve verbatim.
---

# ruthless-editor: every sentence earns its place

First drafts explain themselves to their author. The cutting pass is where writing starts serving the reader. Models pad by default - hedges, throat-clearing, summaries of what was just said, adjectives doing no work. This skill is the antidote, run as a separate pass AFTER drafting.

## The pass

Take the draft. For every sentence ask, in order:

1. **Does the reader need this to act or decide?** No: cut.
2. **Does it repeat something already said?** Restated intros, "in summary" paragraphs that add nothing, the same caveat twice: cut the weaker instance.
3. **Is it hedging without information?** "It's worth noting that", "generally speaking", "as you may know": cut the frame, keep the fact.
4. **Is it abstract where it could be concrete?** "significant performance improvement" becomes "dropped from 2.1s to 340ms". If you do not have the number, say what you do have. Concrete survives, abstract gets cut.
5. **Is the sentence doing two jobs?** Split it or pick the job that matters.

Then the structural cuts:

- **Lead with the outcome.** The first sentence answers "what happened" or "what should I do". Background comes after, for whoever wants it.
- **Kill the throat-clearing intro.** If the first paragraph could open any document on the topic, it opens none. Delete it and check that nothing is lost. Nothing ever is.
- **One idea per paragraph, and the idea in the first line.** Readers scan. Reward the scan.
- **Banned without exception**: filler superlatives (seamless, powerful, robust, cutting-edge, game-changing), empty transitions (moreover, furthermore as sentence glue), unearned "simply" and "just".

## The 30 percent test

Count what you cut. Under 20 percent on a first draft means the pass was timid - go again. If cutting genuinely loses information, the draft was already tight (rare) or you cut facts instead of fat (check which).

## What ruthless does NOT mean

- Not terse to the point of rudeness or ambiguity. Clarity outranks brevity - a short confusing sentence loses to a longer clear one.
- Not stripping the reader's necessary context. The test is "does the READER need it", not "do I find it obvious".
- Not compressing into fragments and jargon chains. Complete sentences, technical terms spelled out on first use.

## The tell

If a sentence needs to be defended with "but it sounds professional", it is padding. Professional IS the absence of padding.
RIGOR_EOF_RUTHLESS_EDITOR
mkdir -p "${DEST}/memory-hygiene"
cat > "${DEST}/memory-hygiene/SKILL.md" <<'RIGOR_EOF_MEMORY_HYGIENE'
---
name: memory-hygiene
description: Use when writing to or reading from any persistent memory an agent keeps across sessions - CLAUDE.md, memory files, notes, project docs meant for future sessions. Governs WHAT deserves persisting, HOW to write it so it survives time, and the recall rule: verify remembered facts against live state before acting on them. Use it also when a session starts by loading old memory.
---

# memory-hygiene: memory is a claim about the past, not a fact about the present

An agent's persistent memory is its highest-leverage asset and its most dangerous one. Good memory compounds: every session starts smarter. Bad memory compounds too: one stale "fact" confidently recalled can outvote the live system in front of you. This skill governs both directions - what goes in, and how what comes out gets trusted.

## Writing: what deserves persistence

Persist the things a future session cannot rederive:

- **Decisions and their WHY.** "We chose X over Y because Z" - the why is the part that evaporates.
- **Corrections received.** When a human corrects you, that is the single most valuable thing to persist - with the reason, so the future session applies the principle, not just the rule.
- **Non-obvious constraints.** The gotcha that cost an hour. The API that lies. The step that must come first.
- **Preferences of the humans you work with.** How they like to be asked, what they care about.

Do NOT persist what the codebase, git history, or docs already record - memory that duplicates a derivable fact is bloat that ages into contradiction. And never persist secrets.

## Writing: how

- **One fact per entry, dated.** "As of 2026-07-02, the deploy hook is armed" ages honestly. Undated facts rot invisibly.
- **Write the trigger with the fact.** A future session needs to know WHEN this matters: "when touching the publish pipeline, remember X".
- **Small and curated beats large and complete.** Memory is loaded into a finite context. Every stale line taxes every future session. Prune when you add.

## Recall: the verification rule

Remembered facts are point-in-time observations. Before ACTING on one:

1. **Grade the staleness risk.** Preferences and decisions age slowly. System state (versions, configs, file locations, what is deployed) ages fast.
2. **Fast-aging fact + consequential action = verify first.** One live probe (does the file still exist, is the flag still set, does the endpoint still respond) before building on the memory.
3. **When memory and live state disagree, live state wins** - and update the memory in the same breath. A contradicted memory left standing will bite the next session too.
4. **Say which you are using.** "Per memory from June" versus "verified just now" - the reader deserves to know the vintage of your facts.

## The maintenance habit

When a memory proves wrong: fix it immediately, do not just route around it. When a memory proves right and important: consider promoting it (clearer trigger, better placement). A memory store nobody prunes becomes a liability with a good reputation.

## The honest limit

This skill gives memory DISCIPLINE inside the tools you already have. What it cannot give is persistence itself - a skill file cannot remember your decisions for you, and everything a session learns still evaporates when the session ends unless something durable catches it. Discipline plus durable storage is the complete system. This skill is the discipline half.
RIGOR_EOF_MEMORY_HYGIENE
echo "Installed 6 skills to ${DEST}"
